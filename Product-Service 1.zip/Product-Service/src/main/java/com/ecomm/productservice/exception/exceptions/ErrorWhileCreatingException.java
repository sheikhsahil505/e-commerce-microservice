package com.ecomm.productservice.exception.exceptions;

public class ErrorWhileCreatingException extends RuntimeException {

    public ErrorWhileCreatingException(String message) {
        super(message);
    }
}
