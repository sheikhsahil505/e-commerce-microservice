package com.ecomm.productservice.model;

public enum ProductStatus {
    ACTIVE, INACTIVE, OUT_OF_STOCK
}
